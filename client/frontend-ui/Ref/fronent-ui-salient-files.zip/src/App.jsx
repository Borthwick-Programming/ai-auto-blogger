import { useState, useEffect } from 'react'

import  WorkflowCanvas  from './components/WorkflowCanvas'
import './App.css'

function App() {
  return <WorkflowCanvas />;
}

export default App
